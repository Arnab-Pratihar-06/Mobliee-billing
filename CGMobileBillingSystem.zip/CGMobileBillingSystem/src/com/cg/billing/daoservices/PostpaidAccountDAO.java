package com.cg.billing.daoservices;

import java.util.List;
import com.cg.billing.beans.PostpaidAccount;

public interface PostpaidAccountDAO {
	PostpaidAccount save(PostpaidAccount postpaidAccount);
	boolean update(PostpaidAccount postpaidAccount);
	PostpaidAccount findOne(int mobileNo);
	List<PostpaidAccount>findAll();
}
